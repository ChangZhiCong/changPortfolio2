const menuLogo = document.querySelector(".menu_logo");
menuLogo.addEventListener("click", function(){
    document.querySelector(".portfolio_navbar").classList.toggle("show");
});
